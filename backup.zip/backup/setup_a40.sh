#!/bin/bash
set -e

echo "========================================="
echo " A40 새 환경 셋업 스크립트"
echo "========================================="

COMFYUI_DIR="/workspace/ComfyUI"
COMFYUI_VERSION="v0.18.1"

# ── 1. ComfyUI 클론 (모델 보존) ──
echo "[*] ComfyUI 셋업..."
if [ -d "$COMFYUI_DIR" ]; then
    if [ -d "$COMFYUI_DIR/models" ]; then
        echo "[*] 기존 models 폴더 백업..."
        mv "$COMFYUI_DIR/models" /workspace/ComfyUI_models_backup
    fi
    echo "[*] 기존 ComfyUI 삭제..."
    rm -rf "$COMFYUI_DIR"
fi

echo "[*] ComfyUI 클론 ($COMFYUI_VERSION)..."
git clone https://github.com/comfyanonymous/ComfyUI.git "$COMFYUI_DIR"
cd "$COMFYUI_DIR"
git checkout "$COMFYUI_VERSION"
echo "[+] ComfyUI $COMFYUI_VERSION 체크아웃 완료"

if [ -d "/workspace/ComfyUI_models_backup" ]; then
    echo "[*] models 폴더 복원..."
    rm -rf "$COMFYUI_DIR/models"
    mv /workspace/ComfyUI_models_backup "$COMFYUI_DIR/models"
    echo "[+] models 복원 완료"
fi

# ── 2. Custom Nodes 클론 ──
echo ""
echo "[*] Custom Nodes 설치..."
cd "$COMFYUI_DIR/custom_nodes"
[ ! -d "ComfyUI-Manager" ] && git clone https://github.com/ltdrdata/ComfyUI-Manager.git
echo "[+] Custom Nodes 클론 완료"

# ── 3. pip 의존성 설치 ──
echo ""
echo "[*] ComfyUI requirements 설치..."
pip install -r "$COMFYUI_DIR/requirements.txt"
echo "[+] ComfyUI main requirements 완료"

for req in "$COMFYUI_DIR"/custom_nodes/*/requirements.txt; do
    if [ -f "$req" ]; then
        node_name=$(basename "$(dirname "$req")")
        echo "[*] $node_name requirements 설치..."
        pip install -r "$req"
        echo "[+] $node_name 완료"
    fi
done


# ── 4. 모델 다운로드 (없는 것만) ──
echo ""
echo "[*] 모델 다운로드 체크..."

HF_TOKEN=$(cat /workspace/backup/huggingface_token.txt 2>/dev/null || echo "")

mkdir -p "$COMFYUI_DIR/models"/{diffusion_models,checkpoints,clip,vae,loras}

download_if_missing() {
    local filepath="$1"
    local url="$2"
    local header="$3"
    if [ ! -f "$filepath" ]; then
        echo "[*] 다운로드: $(basename $filepath)..."
        if [ -n "$header" ]; then
            wget --header="$header" "$url" -O "$filepath"
        else
            wget "$url" -O "$filepath"
        fi
        echo "[+] $(basename $filepath) 완료"
    else
        echo "[=] $(basename $filepath) 이미 존재, 스킵"
    fi
}

# Flux Dev (23GB)
download_if_missing \
    "$COMFYUI_DIR/models/diffusion_models/flux1-dev.safetensors" \
    "https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/main/flux1-dev.safetensors" \
    "Authorization: Bearer $HF_TOKEN"

# T5XXL (9.2GB)
download_if_missing \
    "$COMFYUI_DIR/models/clip/t5xxl_fp16.safetensors" \
    "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp16.safetensors" \
    "Authorization: Bearer $HF_TOKEN"

# CLIP-L (320MB)
download_if_missing \
    "$COMFYUI_DIR/models/clip/clip_l.safetensors" \
    "https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/clip_l.safetensors" \
    "Authorization: Bearer $HF_TOKEN"

# VAE (320MB)
download_if_missing \
    "$COMFYUI_DIR/models/vae/ae.safetensors" \
    "https://huggingface.co/black-forest-labs/FLUX.1-dev/resolve/main/ae.safetensors" \
    "Authorization: Bearer $HF_TOKEN"

# ── 5. Node.js + Claude Code ──

echo ""
if ! command -v node &>/dev/null; then
    echo "[*] Node.js v20 설치..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

if ! command -v claude &>/dev/null; then
    echo "[*] Claude Code CLI 설치..."
    npm install -g @anthropic-ai/claude-code
fi

# ── 6. 백업 복원 (워크플로우, input, output, 설정) ──
BACKUP_DIR="/workspace/backup"

mkdir -p "$COMFYUI_DIR/user/default/workflows"
mkdir -p "$COMFYUI_DIR/input"
mkdir -p "$COMFYUI_DIR/output"

if [ -d "$BACKUP_DIR" ]; then
    echo "[*] 백업에서 복원 중..."

    # 워크플로우 복원
    if [ -d "$BACKUP_DIR/workflows" ] && [ "$(ls -A "$BACKUP_DIR/workflows" 2>/dev/null)" ]; then
        cp -r "$BACKUP_DIR/workflows/"* "$COMFYUI_DIR/user/default/workflows/" 2>/dev/null
        echo "[+] 워크플로우 복원 완료"
    else
        echo "[=] 워크플로우 백업 없음, 스킵"
    fi

    # input 복원 (참고 이미지)
    if [ -d "$BACKUP_DIR/input" ] && [ "$(ls -A "$BACKUP_DIR/input" 2>/dev/null)" ]; then
        cp -r "$BACKUP_DIR/input/"* "$COMFYUI_DIR/input/" 2>/dev/null
        echo "[+] input 이미지 복원 완료"
    fi

    # output 복원
    if [ -d "$BACKUP_DIR/output" ] && [ "$(ls -A "$BACKUP_DIR/output" 2>/dev/null)" ]; then
        cp -r "$BACKUP_DIR/output/"* "$COMFYUI_DIR/output/" 2>/dev/null
        echo "[+] output 이미지 복원 완료"
    fi

    # ComfyUI 설정 복원
    if [ -f "$BACKUP_DIR/comfy.settings.json" ]; then
        cp "$BACKUP_DIR/comfy.settings.json" "$COMFYUI_DIR/user/default/" 2>/dev/null
        echo "[+] ComfyUI 설정 복원 완료"
    fi

    # ComfyUI DB 복원 (실행 히스토리)
    if [ -f "$BACKUP_DIR/comfyui.db" ]; then
        cp "$BACKUP_DIR/comfyui.db" "$COMFYUI_DIR/user/" 2>/dev/null
        echo "[+] ComfyUI DB 복원 완료"
    fi

    # 커스텀 노드 복원 (backup이 setup 내장 코드보다 우선)
    if [ -d "$BACKUP_DIR/custom_nodes" ]; then
        cp "$BACKUP_DIR/custom_nodes/"*.py "$COMFYUI_DIR/custom_nodes/" 2>/dev/null
        echo "[+] 커스텀 노드 복원 완료"
    fi

    # 세션 노트, styles.csv 복원 → /workspace 루트로
    cp "$BACKUP_DIR/session_notes_"*.md /workspace/ 2>/dev/null
    cp "$BACKUP_DIR/pulid_flux_patch_note.md" /workspace/ 2>/dev/null
    echo "[+] 기타 파일 복원 완료"
else
    echo "[!] 백업 폴더 없음 — 첫 실행이면 정상"
fi

echo ""
echo "========================================="
echo " 셋업 완료!"
echo "========================================="
echo ""
echo "남은 작업:"
echo "  1. claude login (API 키 설정)"
echo "  2. ComfyUI 실행: cd $COMFYUI_DIR && python main.py --listen 0.0.0.0"
echo ""
echo "스크립트 위치:"
echo "  시작: bash /workspace/backup/start.sh"
echo "  종료: bash /workspace/backup/shutdown.sh"
